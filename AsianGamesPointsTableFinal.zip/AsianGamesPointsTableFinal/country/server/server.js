const express=require("express");
const dotenv=require("dotenv");
const cors=require("cors")
const app=express();
app.use(cors());
/*app.use(cors({ origin: 'http://localhost:9000' , credentials :  true }));*/

const db=require("../server/config/db");
const route=require("../server/routes/route");
dotenv.config({path:"./config/config.env"});
app.use("/",route);
db(app);

module.export=app;