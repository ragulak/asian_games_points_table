const countrySchema=require("../models/countrySchema");
exports.createCountryDetails=async(req,res)=>{
   try{ 
       
        const createdData=req.body;
        await countrySchema.create(createdData);
        
        res.status(200).send("Success");
   }
  
   catch(error){
       res.status(400).send("Inserting is not working");

   }
}

exports.getAllCountryDetails=async(req,res)=>{
    try{ 
        
         
        const getData= await countrySchema.find({});
         
         res.status(200).json(getData);
    }
   
    catch(error){
        res.status(400).send("Gettingall is notworking");
 
    }
 }