const countrySchema2=require("../models/countrySchema");
exports.UpdateCountryDetails=async(req,res)=>{
   try{ 
       
        const createdData=req.body;
        console.log(req.body)
        const id=req.params.id;
        console.log(id);
        await countrySchema2.findOneAndUpdate({Unique_id:id},createdData);
        res.status(200).send("Success");
   }
   catch(err){  
       res.status(400).send(err)
   }
};
exports.DeleteCountryDetails=async(req,res)=>{
    try{ 
         const id=req.params.id;
         console.log(id);
         await countrySchema2.findOneAndDelete({Unique_id:id});
         res.status(200).send("Success");
    }
    catch(err){
        res.status(400).send(err)
    }
 };exports.createPlayerDetails=async(req,res)=>{
    try{ 
        
         const createdData=req.body;
         await countrySchema.create(createdData);
         
         res.status(200).send("Success");
    }
   
    catch(error){
        res.status(400).send("Inserting is not working");
 
    }
 }