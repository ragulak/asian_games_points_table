const express=require("express");
const router=express.Router();
router.use(express.json());

const CountryController=require("../controller/countryController");
const AdminController=require("../controller/adminController")
// router.post("/asianCountry",CountryController.createCountryDetails);
router.get("/asianCountry",CountryController.getAllCountryDetails);
router.put("/asianCountry/:id",AdminController.UpdateCountryDetails);
router.delete("/asianCountry/:id",AdminController.DeleteCountryDetails)
router.post("/asianCountry",AdminController.createPlayerDetails);
module.exports=router;