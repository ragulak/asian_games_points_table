const mongoose = require("mongoose");
const countrySchema = new mongoose.Schema(
  {
    
    Unique_id: {
      type: Number,
      trim: true,
      unique:true,
      required: [true, "Unique number is required"],
    },
    Nation: {
      type: String,
      trim: true,
      required: [true, "Nation is required"],
    },
    Game: {
      type: String,
      trim: true,
      required: [true, "Game is required"],
    },
    Player: {
      type: String,
      trim: true,
      required: [true, "Player is required"],
    },
   
    Medal: {
        type: String,
        trim: true,
        required: [true, "Medal is required"],
    },
      __v: {
           type: Number, select: false
        }

  }
  
);

module.exports = mongoose.model("Asian_Country", countrySchema);
