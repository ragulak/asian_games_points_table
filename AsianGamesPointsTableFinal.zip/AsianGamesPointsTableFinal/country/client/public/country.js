
var country_json=[];
function getXmlCountryDetails(){ 
    let req=new XMLHttpRequest();
     req.open("GET","http://localhost:5008/asianCountry");
     req.send();
     req.onreadystatechange=function(){
        if(req.readyState===4){
            if(req.status===200){
                country_json=JSON.parse(this.responseText) ; 
                // document.getElementById("adminhead").style.display="none";
                getAdminEditDetails();
        
        }
     }    
}
}
var country=new Map()

function getPlayerDetails(){
    document.getElementById("Countrytable").style.display="none";
    document.getElementById("Countrytable1").style.display="none";
    document.getElementById("Playertable").style.display="block";
  var countryTable="";
  countryTable+=`<thead><tr>
  <th>Nation</th>
  <th>Game</th>
  <th>Player</th>
  <th>Medal</th>
  </tr></thead>
  `
  countryTable+=`<tbody>`;
  for(let key in country_json)
  {
      countryTable+=`
      <tr>
<td>${country_json[key].Nation}</td>
<td>${country_json[key].Game}</td>
<td>${country_json[key].Player}</td>
<td>${country_json[key].Medal}</td>
</tr>
      `    
  }
  countryTable+=`</tbody>`;
document.getElementById("Playertable").innerHTML=countryTable;
}

function getCountryDetails()
{
    var Countries=[];
var countryTable1="";

   document.getElementById("Playertable").style.display="none";
   document.getElementById("Countrytable").style.display="block";
  var  map= new Map();
  countryTable1+=`<thead><tr class="tableHead">
  <th id="rank">Rank</th>
  <th>Nation</th>
  <th id="gold"><b>Gold</b></th>
  <th id="silver">Silver</th>
  <th id="bronze">Bronze</th>
  <th>Total</th>
  </tr></thead>
  `
  for(let i=0;i<country_json.length;i++)
  {
      if(map.has(country_json[i].Nation))
      {}
      else
      map.set(country_json[i].Nation,1)
  }
  let a=[];
  let j=0;
  const values = Array.from(map.keys())
  for(let i=0;i<values.length;i++)
  {
      const gold=country_json.filter((arr)=>
      {
            return arr.Nation===values[i];
      }).filter((arr)=>
      {
            return arr.Medal==="Gold";
      }).reduce((total,obj)=>{
          
              return (total+1);
      },0);
      const silver=country_json.filter((arr)=>
      {
            return arr.Nation===values[i];
      }).filter((arr)=>
      {
            return arr.Medal==="Silver";
      }).reduce((total,obj)=>{
          if(obj.Medal=="Silver"){
              return (total+1);
          }
      },0);
      const Bronze=country_json.filter((arr)=>
      {
            return arr.Nation===values[i];
      }).filter((arr)=>
      {
            return arr.Medal==="Bronze";
      }).reduce((total,obj)=>{
          if(obj.Medal=="Bronze"){
              return (total+1);
          }
      },0)
      Countries.push({Nation:values[i],Gold:gold,Silver:silver,Bronze:Bronze})    
  }
  const country_jsonnew=Countries.map((obj)=>
    {
          return obj.Points=obj.Gold*3+obj.Silver*2+obj.Bronze*1;
    })
    countryTable1+=`<tbody>`
    Countries=Countries.sort(function(a, b) { return a.Points <b.Points ? 1 : -1; })
    console.log(Countries);
    const arr=new Map()
    for(let z=0;z<Countries.length;z++)
    {
        if(arr.has(Countries[z].Points)){}
        else{
         arr.set(Countries[z].Points,1);
        }
    }
    console.log(arr);
    let i=0;
    let dot =1;
    const values1 = Array.from(arr.keys())
    Countries.map((obbb)=>{return obbb.Rank=0;})
    for(let d=0;d<values1.length;d++)
    {
         Countries.filter((obj)=>{
           return obj.Points==values1[d];
         }).map((obj1)=>{return obj1.Rank=dot})
         dot++;
    }
    console.log(Countries);
    for(let ra=0;ra<Countries.length;ra++)
    {
        countryTable1+=`<tr>`
        countryTable1+=`<td>${Countries[ra].Rank}</td>`
        countryTable1+=`
 <td><a onClick='show("${Countries[ra].Nation}")'>${Countries[ra].Nation}<a></td>
 <td>${Countries[ra].Gold}</td>
<td>${Countries[ra].Silver}</td>
<td>${Countries[ra].Bronze}</td>
<td>${Countries[ra].Gold+Countries[ra].Silver+Countries[ra].Bronze}</td>
 </tr>
       ` }
    var TotalGold=Countries.reduce(( total ,obj)=>{return total+obj.Gold},0);
    var TotalSilver=Countries.reduce(( total ,obj)=>{return total+obj.Silver},0);
    var TotalBronze=Countries.reduce(( total ,obj)=>{return total+obj.Bronze},0)
       countryTable1+=`<tr id="total" ><td><b>Total</b></td><td><b>${Countries.length} Entries</b></td><td><b>${TotalGold}</b></td><td><b>${TotalSilver}</b></td><td><b>${TotalBronze}</b></td><td><b>${TotalGold+TotalBronze+TotalSilver}</b></td></tr>`
    countryTable1+=`</tbody>`;
    document.getElementById("Countrytable").innerHTML=countryTable1;
}
let j=1;
let k=0;
function show(valuess)
{
    document.getElementById("Countrytable1").style.display="block";
    var countryTable2="";
  countryTable2+=`<thead><tr >
  <th>Nation</th>
  <th>Game</th>
  <th>Player</th>
  <th>Medal</th>
  </tr></thead>
  `
  const data=country_json.filter((arr)=>
    {
          return arr.Nation==valuess;
    })   
    countryTable2+=`<tbody>`
    for(let i=0;i<data.length;i++)
    {  
      countryTable2+=`
      <tr>
<td>${data[i].Nation}</td>
<td>${data[i].Game}</td>
<td>${data[i].Player}</td>
<td>${data[i].Medal}</td>
</tr>
      `
    }
    countryTable2+=`</tbody>`
    document.getElementById("Countrytable1").innerHTML=countryTable2;
}
function adminCheck()
{
     const Username=document.getElementById("form3Example3").value;
     const Password=document.getElementById("form3Example4").value;
     if(Username=="admin" && Password=="admin123")
     {
        
        location.replace("http://localhost:9000/adminside.html");   
     }
     else{
         alert("username or password is invalid")
     }     
}

function getAdminEditDetails()
{
    var adminBody="";
    var adminHead="";
    // document.getElementById("adminhead").style.display="block";
    console.log(country_json);
    adminHead=`<tr>
    <th>Nation</th>
    <th>Game</th>
    <th>Player</th>
    <th>Medal</th>
    <th>Edit</th>
    <th>Delete</th>
    </tr>`
    var admin="";
    admin=`<h5>Total Number : ${country_json.length}</h5><h5>Total Delete Player data: ${deletecount}</h5><h5>Total Add Player Data : ${Addcount}</h5>
            `
            document.getElementById("dtaa").innerHTML=admin;
     for(let i=0;i<country_json.length;i++)
     {
         
         adminBody+=`<tr>
         <td>${country_json[i].Nation}</td>
         <td id="f1">${country_json[i].Game}</td>
         <td id="l1">${country_json[i].Player}</td>
         <td id="m1">${country_json[i].Medal}</td>
         <td><button type="button" data-toggle="modal" data-target="#edit" data-uid="1" onclick="UserModal('${i}')" class="update btn btn-warning btn-sm"><span class="glyphicon glyphicon-pencil"></span></button></td>
         <td><button type="button" data-toggle="modal" data-target="#delete" data-uid="1" onclick="onestepDelete('${i}')"class="delete btn btn-danger btn-sm"><span class="glyphicon glyphicon-trash"></span></button></td>
         </tr>`
     }
     document.getElementById("adminbody").innerHTML=adminBody;
     document.getElementById("adminhead").innerHTML=adminHead;
}
function onestepDelete(id)
{
    var Modal=`<div id="delete" class="modal fade" role="dialog">
    <div class="modal-dialog">
    <div class="modal-content">
    <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal">×</button>
    <h4 class="modal-title">Delete Data</h4>
    </div>
    <div class="modal-body">
    <strong>Are you sure you want to delete this data?</strong>
    </div>
    <div class="modal-footer">
    <button type="button" id="del" class="btn btn-danger" data-dismiss="modal"onclick="DeletePlayer('${id}')">Delete</button>
    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    </div>
    </div>
    </div>
    </div>`
    document.getElementById("modal123").innerHTML=Modal;
}
var usermodal="";
function UserModal(updatedata)
{
console.log(updatedata);
usermodal+=`
     <div id="edit" class="modal fade" role="dialog">
     <div class="modal-dialog">
    <div class="modal-content">
    <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal">×</button>
    <h4 class="modal-title">Update Player Data</h4>
    </div>
    <div class="modal-body">
    <input id="fn1" type="text" class="form-control" name="fname" placeholder="Nation">
    <br>
    <input id="ln11" type="text" class="form-control" name="fname" placeholder="Game">
    <br>
    <input id="ln111" type="text" class="form-control" name="fname" placeholder="Player">
    <br>
    <input id="mn1" type="text" class="form-control" name="fname" placeholder="Medal">
    </div>
    <div class="modal-footer">
    <button type="button" id="up1" class="btn btn-warning" data-dismiss="modal" onclick="playerUpdate('${updatedata}')">Update</button>
    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    </div>
    </div>
    </div>
    </div>
    `
    console.log(country_json[1].Nation);
    document.getElementById("Update").innerHTML=usermodal;
    document.getElementById("fn1").value=country_json[updatedata].Nation;
    document.getElementById("ln11").value=country_json[updatedata].Game;
    document.getElementById("ln111").value=country_json[updatedata].Player;
    document.getElementById("mn1").value=country_json[updatedata].Medal;
}
function DeletePlayer(delete1)
{
    const id=country_json[delete1].Unique_id;
    var http2=new XMLHttpRequest()
    http2.open("Delete",`http://localhost:5008/asianCountry/${id}`)
    http2.setRequestHeader("Content-Type",'application/json')
    http2.send();
    http2.onreadystatechange=function()
    {
        if(this.readyState==4 )
        {
        if(this.status==200)
        {
            getXmlCountryDetails();

    }
 }
 
}
    deletecount++;
}
var deletecount=0;
var Addcount=0;
function playerUpdate(index)
{ 
const NationValue= document.getElementById("fn1").value;
const GameValue= document.getElementById("ln11").value;
const PlayerValue=  document.getElementById("ln111").value;
const MedalValue=document.getElementById("mn1").value;
const Unique_idnew=Math.round(Math.random()*10000);
const id=country_json[index].Unique_id;
var http2=new XMLHttpRequest()
http2.open("PUT",`http://localhost:5008/asianCountry/${id}`)
http2.setRequestHeader("Content-Type",'application/json')
http2.send(JSON.stringify({
     Unique_id:Unique_idnew,
     Nation:NationValue,
    Game:GameValue,
    Player:PlayerValue,
    Medal: MedalValue
}));
http2.onreadystatechange=function()
{
    if(this.readyState==4 )
    {
    if(this.status==200)
    {
        
        getXmlCountryDetails();
            
    } 
}
 }
}
function AddPlayerDetails()
{
    const NationValue= document.getElementById("fn").value;
    const GameValue= document.getElementById("ln1").value;
    const PlayerValue=  document.getElementById("ln").value;
    const MedalValue=document.getElementById("mn").value;
    const Unique_idnew=Math.round(Math.random()*10000);
    var http2=new XMLHttpRequest()
    http2.open("POST",`http://localhost:5008/asianCountry`)
    http2.setRequestHeader("Content-Type",'application/json')
    http2.send(JSON.stringify({
         Unique_id:Unique_idnew,
         Nation:NationValue,
        Game:GameValue,
        Player:PlayerValue,
        Medal: MedalValue
    }));
    http2.onreadystatechange=function()
    {
        if(this.readyState==4 )
        {
        if(this.status==200)
        {
            
            
            getXmlCountryDetails();
              
            
        }
    }
    
 }
    Addcount++;
}
window.onload=getXmlCountryDetails; 